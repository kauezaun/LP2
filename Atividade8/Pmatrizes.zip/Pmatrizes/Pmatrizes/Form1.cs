﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExerc1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];

            string auxiliar = "";

            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i + 1} numero ", "entrada de dados");
                if (auxiliar == "")
                {
                    break;
                }

                if (!int.TryParse(auxiliar, out vetor[i]))
                {

                    MessageBox.Show("Numero Invalido !");
                    i--;
                }

            }
            Array.Reverse(vetor);
            auxiliar = "";

            foreach (int x in vetor)
            {
                auxiliar += x + "\n";

            
            }

            MessageBox.Show(auxiliar);
        }

        private void btnExerc2_Click(object sender, EventArgs e)
        {
            ArrayList nomes = new ArrayList() { "Ana","André","Beatriz", "Camila","João","Joana","Otavio","Marcelo","Pedro","Thais" };
            nomes.Remove("Otavio");

            string lista="";

            foreach (string s in nomes)
                lista += s + "\n";

            MessageBox.Show(lista);


        }
    }
}

