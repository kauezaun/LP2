﻿namespace PTesteMetodos
{
    partial class frmExercício4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnContarNumeros = new System.Windows.Forms.Button();
            this.btnPosicaoDo1 = new System.Windows.Forms.Button();
            this.btnContarLetras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(263, 38);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(215, 173);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "";
            // 
            // btnContarNumeros
            // 
            this.btnContarNumeros.Location = new System.Drawing.Point(213, 230);
            this.btnContarNumeros.Name = "btnContarNumeros";
            this.btnContarNumeros.Size = new System.Drawing.Size(75, 54);
            this.btnContarNumeros.TabIndex = 2;
            this.btnContarNumeros.Text = "Contar Números";
            this.btnContarNumeros.UseVisualStyleBackColor = true;
            this.btnContarNumeros.Click += new System.EventHandler(this.btnContarNumeros_Click);
            // 
            // btnPosicaoDo1
            // 
            this.btnPosicaoDo1.Location = new System.Drawing.Point(337, 230);
            this.btnPosicaoDo1.Name = "btnPosicaoDo1";
            this.btnPosicaoDo1.Size = new System.Drawing.Size(75, 54);
            this.btnPosicaoDo1.TabIndex = 3;
            this.btnPosicaoDo1.Text = "Posição do 1° caracter branco";
            this.btnPosicaoDo1.UseVisualStyleBackColor = true;
            this.btnPosicaoDo1.Click += new System.EventHandler(this.btnPosicaoDo1_Click);
            // 
            // btnContarLetras
            // 
            this.btnContarLetras.Location = new System.Drawing.Point(455, 230);
            this.btnContarLetras.Name = "btnContarLetras";
            this.btnContarLetras.Size = new System.Drawing.Size(75, 54);
            this.btnContarLetras.TabIndex = 4;
            this.btnContarLetras.Text = "Contar Letras";
            this.btnContarLetras.UseVisualStyleBackColor = true;
            this.btnContarLetras.Click += new System.EventHandler(this.btnContarLetras_Click);
            // 
            // frmExercício4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnContarLetras);
            this.Controls.Add(this.btnPosicaoDo1);
            this.Controls.Add(this.btnContarNumeros);
            this.Controls.Add(this.rchtxtFrase);
            this.Name = "frmExercício4";
            this.Text = "frmExercício4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnContarNumeros;
        private System.Windows.Forms.Button btnPosicaoDo1;
        private System.Windows.Forms.Button btnContarLetras;
    }
}