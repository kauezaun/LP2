﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteEventos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Nome_Click(object sender, EventArgs e)
        {

        }

        private void Endereco_Click(object sender, EventArgs e)
        {

        }

        private void txtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            string Numeros = "123456789";
            bool temNumero = Numeros.Contains(e.KeyChar);

            if (temNumero)
            {
                MessageBox.Show("nome não pode ter números");
                SendKeys.Send("{BACKSPACE}");
            }
        }

      

        private void txtEmail_Validated(object sender, EventArgs e)
        {
            if (txtEmail.Text=="")
            {
                MessageBox.Show("E-mail inválido!");
                txtEmail.Focus();
            }
        }

        private void txtCelular_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (Char)13)//testa enter
            {
                SendKeys.Send("{TAB}");
                e.Handled = true; // desativar o beep
            }
        }

        private void mskbxDataNasc_Validated(object sender, EventArgs e)
        {
            DateTime dtNasc;

            if (!DateTime.TryParse(mskbxDataNasc.Text, out dtNasc))
            {
                MessageBox.Show("Data inválida!");
                mskbxDataNasc.Focus();
            }
            else
                MessageBox.Show("A data é: " +
                    dtNasc.ToShortDateString());
        }

        private void txtEndereco_Validating(object sender, CancelEventArgs e)
        {
            if (txtEndereco.Text =="")
            { MessageBox.Show("Endereço inválido!");
              e.Cancel = true;
            }
        }

        private void mskbxSalario_Validated(object sender, EventArgs e)
        {
            double salario;
            if (!Double.TryParse(mskbxSalario.Text, out salario))
            {
                MessageBox.Show("Salário Inválido!");
                mskbxSalario.Focus();
            }
        }

        private void mskbxDataNasc_Leave(object sender, EventArgs e)
        {
            MessageBox.Show("Data perdeu o foco");
        }

        private void mskbxSalario_Enter(object sender, EventArgs e)
        {
            MessageBox.Show("Salário ganhou o foco");
        }
    }
}
