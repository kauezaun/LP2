﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Segundo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listBox1.Items.Add("Kg");
            listBox1.Items.Add("Pc");
            listBox1.Items.Add("Un");
            listBox1.Items.Add("Mt");
            listBox1.Items.Add("Ml");
            listBox1.Items.Add("Lt");
            listBox1.Items.Add("Arr");
            listBox1.Items.Add("G");

            listBox1.Sorted = true;

            listBox1.SelectedIndex = 0;

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Descrição Vazia!");

            }

            if (checkBox1.Checked)
            {
                MessageBox.Show("Produto Importado");

            }
            else
            {
                MessageBox.Show("Produto Nacional");
            }
            if (comboBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Fornecodr não selecionado!");
            }
            else
            {
                MessageBox.Show("Fornecedor :" + comboBox1.SelectedItem);
            }
            MessageBox.Show(listBox1.SelectedItem.ToString());

            if (radioButton1.Checked)
            {
                MessageBox.Show("Faz parte da cesta básica");

            }
            else
            {
                MessageBox.Show("Não faz parte da cesta básica");

            }
            string stringona = "";

            for (var i = 0; i < checkedListBox1.CheckedItems.Count; i++)
            {
                stringona += checkedListBox1.CheckedItems[i].ToString() + "\n";
            }
            MessageBox.Show(stringona);
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

