# Salve_a_comunidade
Bem vindo ao nosso repositório de TCC ele é destinado ao desenvolvimento do projeto Salve a Comunidade
