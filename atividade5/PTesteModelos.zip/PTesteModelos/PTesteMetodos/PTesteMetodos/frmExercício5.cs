﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercício5 : Form
    {
        int num1, num2;
        public frmExercício5()
        {
            InitializeComponent();
        }

        private void frmExercício5_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
         
         
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            Random ObjR = new Random();

            for (int i = 0; i < 2; i++)
            {
                int r = ObjR.Next(0, 1000);
                if (i == 0)
                {
                    txtNumero1.Text = r.ToString();
                    num1 = r;
                }
                else
                {
                    txtNumero2.Text = r.ToString();
                    num2 = r;
                }
                
            }
            if (num1 < num2)
            {
                MessageBox.Show("O número 1 é menor que o número 2");
            }
            else
            {
                MessageBox.Show("O número 1 é maior que o número 2");
            }

        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtNumero1.Text, out num1) && (txtNumero1.Text != ""))
            {
                MessageBox.Show("Isso não é um número, por favor use o botão sortear ou escreva algum");
                txtNumero1.Clear();
                txtNumero1.Focus();
            }

            }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtNumero2.Text, out num1) && (txtNumero2.Text != ""))
            {
                MessageBox.Show("Isso não é um número, por favor use o botão sortear ou escreva algum");
                txtNumero2.Clear();
                txtNumero2.Focus();
            }
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {

        }
    }
}
