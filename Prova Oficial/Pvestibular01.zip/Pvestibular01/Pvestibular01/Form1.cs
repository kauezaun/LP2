﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pvestibular01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnReceber_Click(object sender, EventArgs e)
        {
            string[,] vetor = new string[3, 5];
            string aux;
            int result = 0;

            for (int i = 1; i < 3; i++)
            {  
                for (int j = 0; j < 5; j++)
                {
                    

                    vetor[i,j] = Interaction.InputBox($"Receber o total de alunos do curso{1} e também o ano {1}: {result}");
                    listBox1.Items.Add($"Total do curso {1} alunos Ano{1}: {result}");

               
                }
                listBox1.Items.Add($"\n\nA soma dos alunos é {result}");
            }
        }

           
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }
    }
}
