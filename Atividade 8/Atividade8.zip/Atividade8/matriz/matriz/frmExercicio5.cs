﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace matriz
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int N = 3;
            string[,] respostas = new string[N, 10];
            string[] gabarito = new string[10];

            for (int i = 0; i < 10; i++)
            {
                gabarito[i] = Interaction.InputBox($"Digite o gabarito da questao {i + 1}:  ");

            }
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    string resposta;
                    do
                    {
                        resposta = Interaction.InputBox($"Digite a resposta da questão {j + 1} do aluno {i + 1}").ToUpper();
                        if (!new[] { "A", "B", "C", "D", "E" }.Contains(resposta))
                        {
                            MessageBox.Show("Resposta inválida! Digite apenas A, B, C, D ou E.");
                        }
                    } while (!new[] { "A", "B", "C", "D", "E" }.Contains(resposta));

                    respostas[i, j] = resposta;
                }
            }


            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    if (respostas[i, j] == gabarito[j])
                    {
                        lboxGabarito.Items.Add($"Aluno {i + 1} acertou a questão {j + 1}");
                    }
                    else
                    {
                        lboxGabarito.Items.Add($"Aluno {i + 1} errou a questão {j + 1}: gabarito {gabarito[j]}, respondeu {respostas[i, j]}");
                    }
                }
            }
        }
    }
}