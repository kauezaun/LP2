﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_
{
    public partial class frmExercicio1: Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int contarEspacos = rtxtFrase.Text.Count(c => c == ' ');
            MessageBox.Show($"Existem {contarEspacos} espaços.");
        }

        private void frmExercicio1_Load(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnQntdR_Click(object sender, EventArgs e)
        {
            int contarRs = rtxtFrase.Text.Count(c => c == 'r' || c == 'R');
            MessageBox.Show($"Existem {contarRs} letras 'R'.");
        }

        private void brnRepeticao_Click(object sender, EventArgs e)
        {
            int contarRepeticao = 0;
            int Letra2 = '\0';
            for (int i = 0; i < rtxtFrase.TextLength; i++)
            {
                int Letra1 = rtxtFrase.Text[i];
                if (Letra1 == Letra2)
                {
                    contarRepeticao += 1;
                }
                Letra2 = Letra1;
            }
            MessageBox.Show($"Existem {contarRepeticao} repetições de letras.");
        }
    }
}
