﻿namespace Atividade_
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rtxtFrase = new System.Windows.Forms.RichTextBox();
            this.lblFrase = new System.Windows.Forms.Label();
            this.btnQntdEspaco = new System.Windows.Forms.Button();
            this.brnRepeticao = new System.Windows.Forms.Button();
            this.btnQntdR = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rtxtFrase
            // 
            this.rtxtFrase.Location = new System.Drawing.Point(234, 12);
            this.rtxtFrase.Name = "rtxtFrase";
            this.rtxtFrase.Size = new System.Drawing.Size(346, 136);
            this.rtxtFrase.TabIndex = 0;
            this.rtxtFrase.Text = "";
            this.rtxtFrase.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // lblFrase
            // 
            this.lblFrase.AutoSize = true;
            this.lblFrase.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblFrase.Location = new System.Drawing.Point(34, 65);
            this.lblFrase.Name = "lblFrase";
            this.lblFrase.Size = new System.Drawing.Size(162, 20);
            this.lblFrase.TabIndex = 1;
            this.lblFrase.Text = "Digite aqui sua frase: ";
            // 
            // btnQntdEspaco
            // 
            this.btnQntdEspaco.Location = new System.Drawing.Point(112, 250);
            this.btnQntdEspaco.Name = "btnQntdEspaco";
            this.btnQntdEspaco.Size = new System.Drawing.Size(153, 62);
            this.btnQntdEspaco.TabIndex = 2;
            this.btnQntdEspaco.Text = "Quantidade de espaços na frase";
            this.btnQntdEspaco.UseVisualStyleBackColor = true;
            this.btnQntdEspaco.Click += new System.EventHandler(this.button1_Click);
            // 
            // brnRepeticao
            // 
            this.brnRepeticao.Location = new System.Drawing.Point(573, 241);
            this.brnRepeticao.Name = "brnRepeticao";
            this.brnRepeticao.Size = new System.Drawing.Size(160, 77);
            this.brnRepeticao.TabIndex = 3;
            this.brnRepeticao.Text = "Quantidade de vezes que uma letra se repete";
            this.brnRepeticao.UseVisualStyleBackColor = true;
            this.brnRepeticao.Click += new System.EventHandler(this.brnRepeticao_Click);
            // 
            // btnQntdR
            // 
            this.btnQntdR.Location = new System.Drawing.Point(332, 241);
            this.btnQntdR.Name = "btnQntdR";
            this.btnQntdR.Size = new System.Drawing.Size(143, 71);
            this.btnQntdR.TabIndex = 4;
            this.btnQntdR.Text = "Quantidade de \'R\' na frase";
            this.btnQntdR.UseVisualStyleBackColor = true;
            this.btnQntdR.Click += new System.EventHandler(this.btnQntdR_Click);
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnQntdR);
            this.Controls.Add(this.brnRepeticao);
            this.Controls.Add(this.btnQntdEspaco);
            this.Controls.Add(this.lblFrase);
            this.Controls.Add(this.rtxtFrase);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.Load += new System.EventHandler(this.frmExercicio1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtxtFrase;
        private System.Windows.Forms.Label lblFrase;
        private System.Windows.Forms.Button btnQntdEspaco;
        private System.Windows.Forms.Button brnRepeticao;
        private System.Windows.Forms.Button btnQntdR;
    }
}