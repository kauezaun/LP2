﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_
{
    public partial class frmExercicio4: Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void frmExercicio4_Load(object sender, EventArgs e)
        {

        }

        private void lblNome_Click(object sender, EventArgs e)
        {

        }

        private void lblSalario_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            string nome = txtNome.Text;
            string matricula = txtMatricula.Text;
            double salarioBase;
            double gratificacao;
            int producao;

            if (int.TryParse(txtProducao.Text,out producao) 
            && double.TryParse(txtSalario.Text,out salarioBase)
            && double.TryParse(txtGratificacao.Text,out gratificacao))
            {
                int B = (producao >= 100) ? 1 : 0;
                int C = (producao >= 100) ? 1 : 0;
                int D = (producao >= 100) ? 1 : 0;

                double salarioBruto = salarioBase + salarioBase * (0.05 * B + 0.10 * C + 0.10 * D) + gratificacao;

                if (salarioBruto > 7000 && producao < 150 && gratificacao == 0)
                {
                    salarioBruto = 7000.00;  
                }

                MessageBox.Show($"Nome: {nome}\nMatrícula: {matricula}\nSalário Bruto: {salarioBruto:C2}");
            }
            else
            {
                MessageBox.Show("Por favor, preencha todos os campos corretamente!");
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
