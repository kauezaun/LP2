﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_
{
    public partial class frmExercicio3: Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string textSemEspaco = txtFrase.Text.Replace(" ", "").ToLower();
            int N = textSemEspaco.Length;
            int aux = N / 2;
            bool ehPalindromo = true;

            for (int i = 0; i < aux; i++)
            {
                if (textSemEspaco[i] != textSemEspaco[N - 1 - i])
                {
                    ehPalindromo = false;
                    break;
                }
            }
            if (ehPalindromo == false)
            {
                MessageBox.Show("Essa frase/palavra não é um palíndromo");
            }
            else
            {
                MessageBox.Show("Essa frase/palavra é um palíndromo");
            }
            

        }

        private void lbl1_Click(object sender, EventArgs e)
        {

        }
    }
}
